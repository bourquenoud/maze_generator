import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class test_maze_generator extends PApplet {

Cell[][] grid;
ArrayList<Cell> explored = new ArrayList<Cell>(); //List of explored cell that have an unexplored cell near them
int size = 80; //Size in number of collumn and row
int numCol;
int numRow;
int scale;
boolean done = false;//When the generation is done

boolean showGene = true; //Show the generation of the maze, otherwise just show a bar (But way faster)

int speed = 1; //Number of pass for each frame

long pass = 0; // Counter off pass
int count = 0; // Count the number of cell that are explored and have no more unexplored close cell

Explorer[] exp = new Explorer[20]; //The list of explorer agents

public void setup()
{
  //Create the windows and calculate the sizes
  
  numCol = size;
  numRow = size;
  scale = width/size;
  
  frameRate(30);

  init();
}

public void draw()
{
  
  //Generate only when there is unexplored cell left
  if (explored.size() != 0)
  {
    for (int j=0; j<speed&&!done; j++) // Do multiple pass in one frame
    {
      pass++;
      //done = true;
      for (int i = 0; i<exp.length && i<(pass/8); i++) //Explore with each agent (but create only a few at the beginning to avoid collisions)
      {
        exp[i].explore();
      }
      
      //Remove unexplorable cell
      for (int i = 0; i<explored.size(); i++)
      {
        //Check each cell close to the tested one (Protected against out of bound array)
        if (grid[constrain(explored.get(i).posX/scale+1, 0, numCol-1)][constrain(explored.get(i).posY/scale, 0, numRow-1)].explored && 
          grid[constrain(explored.get(i).posX/scale-1, 0, numCol-1)][constrain(explored.get(i).posY/scale, 0, numRow-1)].explored && 
          grid[constrain(explored.get(i).posX/scale, 0, numCol-1)][constrain(explored.get(i).posY/scale+1, 0, numRow-1)].explored && 
          grid[constrain(explored.get(i).posX/scale, 0, numCol-1)][constrain(explored.get(i).posY/scale-1, 0, numRow-1)].explored)
        {
          explored.remove(i);
          count++; //Count the number of cell 
        }
      }
      
      if (explored.size() == 0) //When there is no explorable cell left, the maze is finished
      {
        done=true;
        break;
      }
    }

    if (!showGene) //Display a loading bar if showGen is false
    {

      background(0);
      fill(255);
      stroke(255);
      textSize(height/15);
      textAlign(CENTER, CENTER);
      text("Generating maze", height/2, width/2);
      rect(2*width/20, 12*height/20, 16*width/20, 2*height/20);
      fill(0, 255, 0);
      rect(2*width/20, 12*height/20, 16*((float)(count+explored.size())/(numCol*numRow))*width/20, 2*height/20);
      println(explored.size());
    }
  }

  if (explored.size() == 0 || showGene) //Show the maze if done or if showGene is enabled
  {

    //Display
    background(186, 186, 186);
    
    for (int x = 0; x < numCol; x++) //for each cell
    {
      for (int y = 0; y < numRow; y++)
      {
        grid[x][y].display();
      }
    }
    
    noStroke();
    if (!done)//Display the agents
    {  
      for (int i = 0; i<exp.length; i++)
        exp[i].display();
    }
    fill(36, 105, 216);
    rect(1, 1, scale-1, scale-1);
    fill(196, 35, 35);
    rect(scale*(numCol-1)+1, scale*(numRow-1)+1, scale-1, scale-1);
  }
}

public void init()
{
  count = 0;
  explored.clear(); //Empty the explorer list
  done = false;

  grid = new Cell[numCol][numRow]; //
  
  //generate the grid
  for (int x = 0; x < numCol; x++)
  {
    for (int y = 0; y < numRow; y++)
    {
      grid[x][y] = new Cell(x*scale, y*scale, scale);
    }
  }

  //Add the first cell
  explored.add(grid[0][0]);
  grid[0][0].explored = true; 

  //Create the agents
  for (int i = 0; i<exp.length; i++)
    exp[i] = new Explorer( grid, explored);
}


public void keyPressed()
{
  init();
}
/* Cell class
 * 
 */
class Cell
{
  int size;
  
  boolean[] border = {true,true,true,true}; //Walls (top, right, bottom, left)
  boolean explored = false; // If the cell has been explored
  
  int posX, posY; //Graphic position
  
  Cell(int posX, int posY, int size)
  {
   this.posX = posX;
   this.posY = posY;
   this.size = size;
  }
  
  public void display()
  {
    //Color if explored
    if(explored)
    {
      fill(242, 242, 242);
      noStroke();
      rect(posX,posY,size,size);
    }
    
    //Line colors
    if(explored)
      stroke(0); //Full black
    else
      stroke(0,0,0,32); //A bit of transparency
    //Top
    if(border[0])
      line(posX, posY, posX + size, posY);
    //Right
    if(border[1])
      line(posX+size, posY, posX+size, posY+size);
    //Bottom
    if(border[2])
      line(posX, posY+size, posX+size, posY+size);
    //Left
    if(border[3])
      line(posX, posY, posX, posY + size);
      
  }
}
/* Explorer class
 *
 *
 * This is the agent used to explorer the grid and generate the maze.
 */

class Explorer
{
  int[] pos = {0,0}; //Position of the agent
  Cell[][] grid; //Grid it is operating on
  ArrayList<Cell> explored; // The list of already exporated cells
  int retry = 0; //Number of retry to find a new cell
  boolean done; 
  
  Explorer(Cell[][] grid, ArrayList<Cell> explored)
  {
    this.grid = grid;
    this.explored = explored;
    done = false;
  }
  
  
  public boolean explore()
  {
      while(true)
      {
        //Randomly select a direction to go
        int selection = floor(random(0,4));
        
        //--Try to go in the direction-------
        if(selection == 0 && pos[0] < numCol-1)//Right
        {
          if(grid[pos[0]+1][pos[1]].explored == false)//Check if the cell is explored
          {
            grid[pos[0]][pos[1]].border[1] = false; //remove the border
            grid[pos[0]+1][pos[1]].border[3] = false; 
            pos[0]++; //Move the agent
            break; //exit the loop
          }
        }
        else if(selection == 1 && pos[1] < numRow-1)//Down
        {
          if(grid[pos[0]][pos[1]+1].explored == false)
          {
            grid[pos[0]][pos[1]].border[2] = false;
            grid[pos[0]][pos[1]+1].border[0] = false;
            pos[1]++;
            break;
          }
        }
        else if(selection == 2 && pos[0] > 0)//Left
        {
          if(grid[pos[0]-1][pos[1]].explored == false)
          {
            grid[pos[0]][pos[1]].border[3] = false;
            grid[pos[0]-1][pos[1]].border[1] = false;
            pos[0]--;
            break;
          }
        }
        else if(selection == 3 && pos[1] > 0)//Up
        {
          if(grid[pos[0]][pos[1]-1].explored == false)
          {
            grid[pos[0]][pos[1]].border[0] = false;
            grid[pos[0]][pos[1]-1].border[2] = false;
            pos[1]--;
            break;
          }
        }
          
          //Go back somewhere on an already explored cell if stuck
          if ((grid[constrain(pos[0]+1, 0, numCol-1)][constrain(pos[1], 0, numRow-1)].explored && 
          grid[constrain(pos[0]-1, 0, numCol-1)][constrain(pos[1], 0, numRow-1)].explored && 
          grid[constrain(pos[0], 0, numCol-1)][constrain(pos[1]+1, 0, numRow-1)].explored && 
          grid[constrain(pos[0], 0, numCol-1)][constrain(pos[1]-1, 0, numRow-1)].explored))
          {
            int targ = floor(random(0,explored.size())); //Randomly select a cell
            pos[0] = explored.get(targ).posX/scale;
            pos[1] = explored.get(targ).posY/scale;
            retry++; //If it did not find a valid cell after a few try, stop.
            if(retry > 50)
              return true;
          }
      }
      
      explored.add(grid[pos[0]][pos[1]]); //Add the actual cell in the explored list
      grid[pos[0]][pos[1]].explored = true; //Indicate that the cell was explored
      
     return done;
  }
  
  public void display()
  {
    //Simply display a green square
    noStroke();
    fill(50,200,50);
    rect(pos[0]*scale+1,pos[1]*scale+1, scale-1, scale-1);
  }
  
}
  public void settings() {  size(801, 801); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "test_maze_generator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
