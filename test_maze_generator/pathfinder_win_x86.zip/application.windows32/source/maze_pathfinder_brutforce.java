import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class maze_pathfinder_brutforce extends PApplet {

Cell[][] grid;
int size = 100; //Size in number of collumn and row
int numCol;
int numRow;
int scale;
boolean pathDone = false;
boolean done = false;//When the generation is done

boolean showGene = false; //Show the generation of the maze, otherwise just show a bar (But way faster)

int speedGene = 500; //Number of pass for each frame
int speedPathFind = 3; //Number of pass for each frame
int speedPathDisp = 10; //Number of pass for each frame

long pass = 0; // Counter off pass
int count = 0; // Count the number of cell that are explored and have no more unexplored close cell

ArrayList<Explorer> exp; //The list of explorer agents
Pathfinding path;

public void setup()
{
  //Create the windows and calculate the sizes
  
  numCol = size;
  numRow = size;
  scale = width/size;
  
  frameRate(30);

  init();
}

public void draw()
{
  
  //Generate only when there is unexplored cell left
  if (!done)
  {
    for (int j=0; j<speedGene&&!done; j++) // Do multiple pass in one frame
    {
      pass++;
      done = true;
      for (int i = 0; i<exp.size() && i<(pass/8+1); i++) //Explore with each agent (but create only a few at the beginning to avoid collisions)
      {
        if(exp.get(i).explore() == false)
          done = false;
      }
    }

    if (!showGene) //Display a loading bar if showGen is false
    {
      int cumulCount = count;
      background(0);
      fill(255);
      stroke(255);
      textSize(height/15);
      textAlign(CENTER, CENTER);
      text("Generating maze", height/2, width/2);
      rect(2*width/20, 12*height/20, 16*width/20, 2*height/20);
      fill(0, 255, 0);
      for (int i = 0; i<exp.size() && i<(pass/8+1); i++) //Explore with each agent (but create only a few at the beginning to avoid collisions)
       cumulCount+=exp.get(i).explored.size();
      rect(2*width/20, 12*height/20, 16*((float)(cumulCount)/(numCol*numRow))*width/20, 2*height/20);
    }
  }

  if (done || showGene) //Show the maze if done or if showGene is enabled
  {
    
    for (int x = 0; x < numCol; x++) //for each cell
    {
      for (int y = 0; y < numRow; y++)
      {
        grid[x][y].display();
      }
    }
    
    noStroke();
    if (!done)//Display the agents
    {  
      for (int i = 0; i<exp.size(); i++)
        exp.get(i).display();
    }
    fill(36, 105, 216);
    rect(scale*(size/2)+1, 0, scale-1, scale-1);
    fill(196, 35, 35);
    rect(scale*(size/2)+1, scale*(size-1)+1, scale-1, scale-1);
  }
  
  //Exploring
  if (done)
  {
    if(!pathDone)
    {
      for (int j=0; j<speedPathFind; j++) // Do multiple pass in one frame
      pathDone = path.explore();
    }
    else
    {
      for (int j=0; j<speedPathDisp; j++) // Do multiple pass in one frame
      path.backTrack();
    }
  }
}

public void init()
{
  count = 0;
  done = false;
  pathDone = false;

  grid = new Cell[numCol][numRow]; //
  
  //generate the grid
  for (int x = 0; x < numCol; x++)
  {
    for (int y = 0; y < numRow; y++)
    {
      grid[x][y] = new Cell(x*scale, y*scale, scale);
    }
  }
  grid[size/2][0].explored = true; 

  exp = new ArrayList<Explorer>();

  //Create the agents
  for (int i = 0; i<2; i++)
    exp.add(new Explorer( grid, size/2, 0));
    
  path = new Pathfinding(grid,size/2,0,size/2,numRow-1);
  
  
    //Display
    background(186, 186, 186);
    
    for (int x = 0; x < numCol; x++) //for each cell
    {
      for (int y = 0; y < numRow; y++)
      {
        grid[x][y].toUpdate = true;
        grid[x][y].display();
      }
    }
}


public void keyPressed()
{
  init();
}
/* Cell class
 * 
 */
class Cell
{
  int size;

  boolean[] border = {true, true, true, true}; //Walls (top, right, bottom, left)
  boolean explored = false; // If the cell has been explored
  int pathCost = -1; //Cost to start from here
  boolean onPath = false;
  boolean toUpdate = true;
  
  boolean debug = false;

  int posX, posY; //Graphic position

  Cell(int posX, int posY, int size)
  {
    this.posX = posX;
    this.posY = posY;
    this.size = size;
  }

  public void display()
  {
    if (toUpdate)
    {
      //Color if explored
      if (explored && pathCost == -1)
      {
        fill(242, 242, 242);
        noStroke();
        rect(posX, posY, size, size);
      } else if (pathCost > 0)
      {
        fill(constrain(pathCost/4, 0, 255), constrain(255-pathCost/4, 0, 255), 50);
        noStroke();
        rect(posX, posY, size, size);
        if (onPath)
        {

          fill(255, 253, 155);
          if (size > 100)
          {
            noStroke();
            ellipse(posX+size/2, posY+size/2, size/4, size/4);
          } else
          {
            rect(posX, posY, size, size);
          }
        }
      }

      //Line colors
      if (explored)
        stroke(0); //Full black
      else
        stroke(0, 0, 0, 32); //A bit of transparency
      //Top
      if (border[0])
        line(posX, posY, posX + size, posY);
      //Right
      if (border[1])
        line(posX+size, posY, posX+size, posY+size);
      //Bottom
      if (border[2])
        line(posX, posY+size, posX+size, posY+size);
      //Left
      if (border[3])
        line(posX, posY, posX, posY + size);

      toUpdate = false;
    }
  }
}
/* Explorer class
 *
 *
 * This is the agent used to explorer the grid and generate the maze.
 */

class Explorer
{

  ArrayList<Cell> explored; //List of explored cell that have an unexplored cell near them
  float branProb = 0.05f;

  int[] pos = {0, 0}; //Position of the agent
  Cell[][] grid; //Grid it is operating on
  int retry = 0; //Number of retry to find a new cell
  boolean done; 

  Explorer(Cell[][] grid, int startPosX, int startPosY)
  {
    explored = new ArrayList<Cell>(); //List of explored cell that have an unexplored cell near them
    pos[0] = startPosX;
    pos[1] = startPosY;
    explored.add(grid[startPosX][startPosY]);
    this.grid = grid;
    done = false;
  }
  
   Explorer(Cell[][] grid, int startPosX, int startPosY, ArrayList<Cell> explored)
  {
    this.explored = (ArrayList<Cell>)explored.clone(); //List of explored cell that have an unexplored cell near them
    pos[0] = startPosX;
    pos[1] = startPosY;
    explored.add(grid[startPosX][startPosY]);
    this.grid = grid;
    done = false;
  }


  public boolean explore()
  {
    while (true)
    {

      //Remove unexplorable cell
      for (int i = 0; i<explored.size(); i++)
      {
        explored.get(i).debug = true;
        //Check each cell close to the tested one (Protected against out of bound array)
        if (grid[constrain(explored.get(i).posX/scale+1, 0, numCol-1)][constrain(explored.get(i).posY/scale, 0, numRow-1)].explored && 
          grid[constrain(explored.get(i).posX/scale-1, 0, numCol-1)][constrain(explored.get(i).posY/scale, 0, numRow-1)].explored && 
          grid[constrain(explored.get(i).posX/scale, 0, numCol-1)][constrain(explored.get(i).posY/scale+1, 0, numRow-1)].explored && 
          grid[constrain(explored.get(i).posX/scale, 0, numCol-1)][constrain(explored.get(i).posY/scale-1, 0, numRow-1)].explored)
        {
          explored.get(i).toUpdate = true; //debug
          explored.get(i).debug = false;
          explored.remove(i);
          count++; //Count the number of cell
        }
      }


      if (explored.size() == 0) //When there is no explorable cell left, the maze is finished
      {
        done=true;
        return true;
      }

      //Go back somewhere on an already explored cell if stuck
      if (((
        grid[constrain(pos[0]+1, 0, numCol-1)][constrain(pos[1], 0, numRow-1)].explored && 
        grid[constrain(pos[0]-1, 0, numCol-1)][constrain(pos[1], 0, numRow-1)].explored && 
        grid[constrain(pos[0], 0, numCol-1)][constrain(pos[1]+1, 0, numRow-1)].explored && 
        grid[constrain(pos[0], 0, numCol-1)][constrain(pos[1]-1, 0, numRow-1)].explored) ||
        random(0, 1) < branProb
        ))
      {
        grid[pos[0]][pos[1]].toUpdate = true;

        int targ = floor(random(constrain(39*explored.size()/40-10, 0, explored.size()), explored.size())); //Randomly select a cell
        pos[0] = explored.get(targ).posX/scale;
        pos[1] = explored.get(targ).posY/scale;

        /*pos[0] = explored.get(explored.size()-1).posX/scale;
         pos[1] = explored.get(explored.size()-1).posY/scale;*/
         //retry++; //If it did not find a valid cell after a few try, stop.
        /*if (retry > 50)
          return true;*/
      }

      //Randomly select a direction to go
      int selection = floor(random(0, 4));

      //--Try to go in the direction-------
      if (selection == 0 && pos[0] < numCol-1)//Right
      {
        if (grid[pos[0]+1][pos[1]].explored == false)//Check if the cell is explored
        {
          grid[pos[0]][pos[1]].border[1] = false; //remove the border
          grid[pos[0]+1][pos[1]].border[3] = false; 

          grid[pos[0]][pos[1]].toUpdate = true;
          grid[pos[0]+1][pos[1]].toUpdate = true;

          pos[0]++; //Move the agent

          break; //exit the loop
        }
      } else if (selection == 1 && pos[1] < numRow-1)//Down
      {
        if (grid[pos[0]][pos[1]+1].explored == false)
        {
          grid[pos[0]][pos[1]].border[2] = false;
          grid[pos[0]][pos[1]+1].border[0] = false;

          grid[pos[0]][pos[1]].toUpdate = true;
          grid[pos[0]][pos[1]+1].toUpdate = true;

          pos[1]++;

          break;
        }
      } else if (selection == 2 && pos[0] > 0)//Left
      {
        if (grid[pos[0]-1][pos[1]].explored == false)
        {
          grid[pos[0]][pos[1]].border[3] = false;
          grid[pos[0]-1][pos[1]].border[1] = false;

          grid[pos[0]][pos[1]].toUpdate = true;
          grid[pos[0]-1][pos[1]].toUpdate = true;

          pos[0]--;

          break;
        }
      } else if (selection == 3 && pos[1] > 0)//Up
      {
        if (grid[pos[0]][pos[1]-1].explored == false)
        {
          grid[pos[0]][pos[1]].border[0] = false;
          grid[pos[0]][pos[1]-1].border[2] = false;

          grid[pos[0]][pos[1]].toUpdate = true;
          grid[pos[0]][pos[1]-1].toUpdate = true;

          pos[1]--;

          break;
        }
      }
    }

    explored.add(grid[pos[0]][pos[1]]); //Add the actual cell in the explored list
    grid[pos[0]][pos[1]].explored = true; //Indicate that the cell was explored

    return done;
  }

  public void display()
  {
    //Simply display a green square
    noStroke();
    fill(50, 200, 50);
    rect(pos[0]*scale+1, pos[1]*scale+1, scale-1, scale-1);
  }
}
class Pathfinding
{
  Cell[][] grid;
  ArrayList<Cell> listed;
  boolean done = false;
  int goalX;
  int goalY;
  Cell shortest;

  Pathfinding(Cell[][] grid,int startX, int startY, int goalX, int goalY)
  {
    this.grid = grid;
    this.goalX = goalX;
    this.goalY = goalY;
    listed = new ArrayList<Cell>();
    listed.add(grid[startX][startY]);// Add the start cell
    grid[startX][startY].pathCost = 0;
    shortest = null;
    println(goalX +";" +goalY);
  }

  public boolean explore()//Return true when done
  {
    ArrayList<Cell> newList = new ArrayList<Cell>();
    int sizeList = listed.size();
    for (int i = 0; i< sizeList; i++)
    {
      Cell c = listed.get(i);
      if (c.posX/scale == goalX && c.posY/scale == goalY)
      {
        println(c.pathCost);
        shortest = c;
        c.onPath = true;
        //done = true;
        //return true;
      }
      //Select the next cells to be explored and add them to the "listed" array
      if (c.border[1] == false)
      {
        if (grid[c.posX/scale+1][c.posY/scale].pathCost == -1)
        {
          grid[c.posX/scale+1][c.posY/scale].pathCost = c.pathCost + 1;
          newList.add(grid[c.posX/scale+1][c.posY/scale]);
        }
      }
      if (c.border[2] == false)
      {
        if (grid[c.posX/scale][c.posY/scale+1].pathCost == -1)
        {
          grid[c.posX/scale][c.posY/scale+1].pathCost = c.pathCost + 1;
          newList.add(grid[c.posX/scale][c.posY/scale+1]);
        }
      }
      if (c.border[3] == false)
      {
        if (grid[c.posX/scale-1][c.posY/scale].pathCost == -1)
        {
          grid[c.posX/scale-1][c.posY/scale].pathCost = c.pathCost + 1;
          newList.add(grid[c.posX/scale-1][c.posY/scale]);
        }
      }
      if (c.border[0] == false)
      {
        if (grid[c.posX/scale][c.posY/scale-1].pathCost == -1)
        {
          grid[c.posX/scale][c.posY/scale-1].pathCost = c.pathCost + 1;
          newList.add(grid[c.posX/scale][c.posY/scale-1]);
        }
      }
    }

    listed = newList;
    
    for(int i=0; i<listed.size(); i++)
      listed.get(i).toUpdate = true;

    //return done;
    return (listed.size()==0);
  }

  public boolean backTrack()
  {
    boolean found = false;
    Cell tmpShortest = shortest;
    //println("Shortest coordinates : " + shortest.posX/scale + ";" + shortest.posY/scale);
    //Select the next cells to be explored and add them to the "listed" array
    if (shortest.border[1] == false && tmpShortest.pathCost > grid[shortest.posX/scale+1][shortest.posY/scale].pathCost && 0 < grid[shortest.posX/scale+1][shortest.posY/scale].pathCost)
    {
      tmpShortest = grid[shortest.posX/scale+1][shortest.posY/scale];
      found = true;
    }
    if (shortest.border[2] == false && tmpShortest.pathCost > grid[shortest.posX/scale][shortest.posY/scale+1].pathCost && 0 < grid[shortest.posX/scale][shortest.posY/scale+1].pathCost)
    {
      tmpShortest = grid[shortest.posX/scale][shortest.posY/scale+1];
      found = true;
    }
    if (shortest.border[3] == false && tmpShortest.pathCost > grid[shortest.posX/scale-1][shortest.posY/scale].pathCost && 0 < grid[shortest.posX/scale-1][shortest.posY/scale].pathCost)
    {
      tmpShortest = grid[shortest.posX/scale-1][shortest.posY/scale];
      found = true;
    }
    if (shortest.border[0] == false && tmpShortest.pathCost > grid[shortest.posX/scale][shortest.posY/scale-1].pathCost && 0 < grid[shortest.posX/scale][shortest.posY/scale-1].pathCost)
    {
      tmpShortest = grid[shortest.posX/scale][shortest.posY/scale-1];
      found = true;
    }
    tmpShortest.onPath = true;
    shortest = tmpShortest;
    shortest.toUpdate = true;

    return !found;
  }
}
  public void settings() {  size(1001, 1001); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "maze_pathfinder_brutforce" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
